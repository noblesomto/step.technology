      <?php


return [
    'site_title' => 'Society of Technology and Energy Professionals (STEP)',
    'site_email' => 'info@step.technology',
    'site_phone' => '7055393098'
];