<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>Blog Posts</h1>

</div><!-- End Page Title -->

<section class="section">
  <div class="row">


    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
          <h5 class="card-title">All Blog Post</h5>
          <?php if(session('status')): ?>
                <div class="alert alert-<?php echo e(session('status')['type']); ?>">
                    <?php echo e(session('status')['text']); ?>

                </div>
            <?php endif; ?>

          <!-- Table with stripped rows -->
          <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Blog Title</th>
                <th scope="col">Published Date</th>
                <th scope="col">Action</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($row->blog_title); ?></td>
                <td><?php echo e($row->created_at->format('j F Y')); ?> </td>
                <td>
                    <?php if( $row->blog_status == 1 ): ?>
                        <a href="/blogpost/post-status/<?php echo e($row->blog_id); ?>/0">Unpublish</a>
                    <?php else: ?>
                        <a href="/blogpost/post-status/<?php echo e($row->blog_id); ?>/1">Publish</a>
                    <?php endif; ?>  
                </td>
                <td><a href="/blogpost/edit-post/<?php echo e($row->blog_id); ?>">Edit Post</a></td>
                <td><a href="/blogpost/delete-post/<?php echo e($row->blog_id); ?>" onclick="return confirm('Are you sure you want to delete?');">Delete</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
        </div>
          <!-- End Table with stripped rows -->

        </div>
      </div>

      



    </div>
  </div>
</section>

</main><!-- End #main -->
<script>
function myFunction() {
  confirm("Are you sure you want to delete?");
}
</script>
<?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/laravel/step/resources/views/backend/blog/posts.blade.php ENDPATH**/ ?>