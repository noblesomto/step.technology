<?php echo $__env->make('dashboard.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('backend/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<main id="main" class="main">

    <div class="pagetitle">
    <h1>USER PROFILE</h1>
  
    </div><!-- End Page Title -->
    
    <section class="section">
    <div class="row">
    <div class="col-lg-12">
    
        <div class="card">
        <div class="card-body">
            <h5 class="card-title">Edit Profile</h5>
            <?php if(session('status')): ?>
                <div class="alert alert-<?php echo e(session('status')['type']); ?>">
                    <?php echo e(session('status')['text']); ?>

                </div>
            <?php endif; ?>
            <!-- General Form Elements -->
            <form action="/user/profile" method="POST" role="form" class="" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>

             <?php if($user->user_type=="Young Professional" || $user->user_type=="Corporate Professional"): ?>
            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Title</label>
                <div class="col-sm-10">
                    <?php if($errors->has('first_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                    <?php endif; ?>
                <select class="form-control" name="title">
                    <option value="">Select Title</option>
                    <option value="Mr" <?php echo e(($user->title =='Mr') ? "selected" : ""); ?>>Mr</option>
                    <option value="Miss" <?php echo e(($user->title =='Miss') ? "selected" : ""); ?>>Miss</option>
                    <option value="Mrs" <?php echo e(($user->title =='Mrs') ? "selected" : ""); ?>>Mrs</option>
                    <option value="Engr" <?php echo e(($user->title =='Engr') ? "selected" : ""); ?>>Engr</option>
                    <option value="Dr" <?php echo e(($user->title =='Dr') ? "selected" : ""); ?>>Dr</option>
                    <option value="Prof" <?php echo e(($user->title =='Prof') ? "selected" : ""); ?>>Prof</option>
                </select>
                </div>
            </div>
    
            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">First Name</label>
                <div class="col-sm-10">
                    <?php if($errors->has('first_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="first_name" class="form-control" placeholder="First Name" value="<?php echo e($user->first_name); ?>" required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Last Name</label>
                <div class="col-sm-10">
                    <?php if($errors->has('last_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="last_name" class="form-control" placeholder="Last Name" value="<?php echo e($user->last_name); ?>" required>
                </div>
            </div>


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Phone </label>
                <div class="col-sm-10">
                    <?php if($errors->has('phone')): ?>
                        <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                    <?php endif; ?>
                <input type="text" name="phone" class="form-control" placeholder="Phone" value="<?php echo e($user->phone); ?>"  required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Profession</label>
                <div class="col-sm-10">
                    <?php if($errors->has('profession')): ?>
                        <span class="text-danger"><?php echo e($errors->first('profession')); ?></span>
                    <?php endif; ?>
                <input type="text" name="profession" class="form-control" placeholder="Profession" value="<?php echo e($user->profession); ?>" required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e($user->email); ?>" readonly >
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Address </label>
                <div class="col-sm-10">
                    <?php if($errors->has('address')): ?>
                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                    <?php endif; ?>
                <input type="text" name="address" class="form-control" placeholder="Address" value="<?php echo e($user->address); ?>" >
                </div>
            </div> 


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">City </label>
                <div class="col-sm-10">
                    <?php if($errors->has('city')): ?>
                        <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                    <?php endif; ?>
                <input type="text" name="city" class="form-control" placeholder="City" value="<?php echo e($user->city); ?>" >
                </div>
            </div>  


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">State </label>
                <div class="col-sm-10">
                    <?php if($errors->has('state')): ?>
                        <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                    <?php endif; ?>
                <input type="text" name="state" class="form-control" placeholder="State" value="<?php echo e($user->state); ?>" >
                </div>
            </div>  
            <hr>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Company Name </label>
                <div class="col-sm-10">
                    <?php if($errors->has('company_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('company_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="company_name" class="form-control" placeholder="Company Name" value="<?php echo e($user->company_name); ?>" >
                </div>
            </div>

            <hr>      

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Referee Name </label>
                <div class="col-sm-10">
                    <?php if($errors->has('referee_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('referee_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="referee_name" class="form-control" placeholder="Full Name" value="<?php echo e($user->referee_name); ?>" required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Referee Email </label>
                <div class="col-sm-10">
                    <?php if($errors->has('referee_email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('referee_email')); ?></span>
                    <?php endif; ?>
                <input type="email" name="referee_email" class="form-control" placeholder="Referee Email" value="<?php echo e($user->referee_email); ?>" required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Referee Phone </label>
                <div class="col-sm-10">
                    <?php if($errors->has('referee_phone')): ?>
                        <span class="text-danger"><?php echo e($errors->first('referee_phone')); ?></span>
                    <?php endif; ?>
                <input type="text" name="referee_phone" class="form-control" placeholder="Referee Phone" value="<?php echo e($user->referee_phone); ?>" required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Referee Address </label>
                <div class="col-sm-10">
                    <?php if($errors->has('referee_address')): ?>
                        <span class="text-danger"><?php echo e($errors->first('referee_address')); ?></span>
                    <?php endif; ?>
                <input type="text" name="referee_address" class="form-control" placeholder="Referee Address" value="<?php echo e($user->referee_address); ?>" required>
                </div>
            </div>
            <hr>  


            <?php elseif($user->user_type=="Undergraduate"): ?>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Title</label>
                <div class="col-sm-10">
                    <?php if($errors->has('title')): ?>
                        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                    <?php endif; ?>
                <select class="form-control" name="title">
                    <option value="">Select Title</option>
                    <option value="Mr" <?php echo e(($user->title =='Mr') ? "selected" : ""); ?>>Mr</option>
                    <option value="Miss" <?php echo e(($user->title =='Miss') ? "selected" : ""); ?>>Miss</option>
                    <option value="Mrs" <?php echo e(($user->title =='Mrs') ? "selected" : ""); ?>>Mrs</option>

                </select>
                </div>
            </div>
    
            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">First Name</label>
                <div class="col-sm-10">
                    <?php if($errors->has('first_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="first_name" class="form-control" placeholder="First Name" value="<?php echo e($user->first_name); ?>" required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Last Name</label>
                <div class="col-sm-10">
                    <?php if($errors->has('last_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="last_name" class="form-control" placeholder="Last Name" value="<?php echo e($user->last_name); ?>" required>
                </div>
            </div>


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Phone </label>
                <div class="col-sm-10">
                    <?php if($errors->has('phone')): ?>
                        <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                    <?php endif; ?>
                <input type="text" name="phone" class="form-control" placeholder="Phone" value="<?php echo e($user->phone); ?>"  required>
                </div>
            </div>


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e($user->email); ?>" readonly >
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Address </label>
                <div class="col-sm-10">
                    <?php if($errors->has('address')): ?>
                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                    <?php endif; ?>
                <input type="text" name="address" class="form-control" placeholder="Address" value="<?php echo e($user->address); ?>" >
                </div>
            </div> 


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">City </label>
                <div class="col-sm-10">
                    <?php if($errors->has('city')): ?>
                        <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                    <?php endif; ?>
                <input type="text" name="city" class="form-control" placeholder="City" value="<?php echo e($user->city); ?>" >
                </div>
            </div>  


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">State </label>
                <div class="col-sm-10">
                    <?php if($errors->has('state')): ?>
                        <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                    <?php endif; ?>
                <input type="text" name="state" class="form-control" placeholder="State" value="<?php echo e($user->state); ?>" >
                </div>
            </div>  
            <hr>


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">School Name </label>
                <div class="col-sm-10">
                    <?php if($errors->has('school_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('school_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="school_name" class="form-control" placeholder="School Name" value="<?php echo e($user->school_name); ?>" >
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Faculty </label>
                <div class="col-sm-10">
                    <?php if($errors->has('school_faculty')): ?>
                        <span class="text-danger"><?php echo e($errors->first('school_faculty')); ?></span>
                    <?php endif; ?>
                <input type="text" name="school_faculty" class="form-control" placeholder="Faculty" value="<?php echo e($user->school_faculty); ?>" >
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Department</label>
                <div class="col-sm-10">
                    <?php if($errors->has('school_dept')): ?>
                        <span class="text-danger"><?php echo e($errors->first('school_dept')); ?></span>
                    <?php endif; ?>
                <input type="text" name="school_dept" class="form-control" placeholder="Department" value="<?php echo e($user->school_dept); ?>" >
                </div>
            </div>
            <hr>  
            <?php elseif($user->user_type=="Corporate Organisation"): ?>
            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Company Name </label>
                <div class="col-sm-10">
                    <?php if($errors->has('company_name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('company_name')); ?></span>
                    <?php endif; ?>
                <input type="text" name="company_name" class="form-control" placeholder="Company Name" value="<?php echo e($user->company_name); ?>" >
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Phone </label>
                <div class="col-sm-10">
                    <?php if($errors->has('phone')): ?>
                        <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                    <?php endif; ?>
                <input type="text" name="phone" class="form-control" placeholder="Phone" value="<?php echo e($user->phone); ?>"  required>
                </div>
            </div>


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e($user->email); ?>" readonly >
                </div>
            </div>

            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">Address </label>
                <div class="col-sm-10">
                    <?php if($errors->has('address')): ?>
                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                    <?php endif; ?>
                <input type="text" name="address" class="form-control" placeholder="Address" value="<?php echo e($user->address); ?>" >
                </div>
            </div> 


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">City </label>
                <div class="col-sm-10">
                    <?php if($errors->has('city')): ?>
                        <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                    <?php endif; ?>
                <input type="text" name="city" class="form-control" placeholder="City" value="<?php echo e($user->city); ?>" >
                </div>
            </div>  


            <div class="row mb-3">
                <label for="inputText" class="col-sm-2 col-form-label">State </label>
                <div class="col-sm-10">
                    <?php if($errors->has('state')): ?>
                        <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                    <?php endif; ?>
                <input type="text" name="state" class="form-control" placeholder="State" value="<?php echo e($user->state); ?>" >
                </div>
            </div>  

            <?php endif; ?>
     
            
    
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Update Profile</button>
                </div>
            </div>
    
            </form><!-- End General Form Elements -->
    
        </div>
        </div>
    
    </div>
    
    </div>
    </section>
    
    </main><!-- End #main -->

    <?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/laravel/step/resources/views/dashboard/profile.blade.php ENDPATH**/ ?>