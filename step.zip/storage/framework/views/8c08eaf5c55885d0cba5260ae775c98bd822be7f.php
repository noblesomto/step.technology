<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(<?php echo e(asset('frontend/img/banner.jpg')); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs">
                    <h1>ACCOUNT SECTION</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start breadcrumb bottom area-->     
<section class="breadcrumb-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="left pull-left">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                        <li class="active">Register</li>
                    </ul>
                </div>
                <div class="right pull-right">
                    
                </div>    
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb bottom area-->

<!--Start Business planning area-->
<section id="single-service-area">
    <div class="container">
        <div class="row login-register-area">
            <div class="col-lg-8 col-md-7 col-sm-12 col-xs-12 pull-right">
                <div class="content-box ">
                    <!--Start top content-->
                    <div class="form register">
                    <div class="sec-title">
                        <h1>Register as Young Professional</h1>
                        <span class="border"></span>
                        <p>
                            <?php if(session('status')): ?>
                                <div class="alert alert-<?php echo e(session('status')['type']); ?>">
                                    <?php echo e(session('status')['text']); ?>

                                </div>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="row">
                        <form action="/register" method="POST">
                        <?php echo csrf_field(); ?>
                            <div class="col-md-12">
                                <?php if($errors->has('title')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                                <div class="input-field">
                                    <select class="form-control" name="title" required>
                                        <option value="">Select Title</option>
                                        <option value="Mr">Mr</option>
                                        <option value="Miss">Miss</option>
                                        <option value="Mrs">Mrs</option>
                                        <option value="Engr">Engr</option>
                                        <option value="Dr">Dr</option>
                                        <option value="Prof">Prof</option>
                                    </select>
                                </div>    
                            </div> 
                            <div class="col-md-12">
                                <?php if($errors->has('first_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                                <?php endif; ?>
                                <div class="input-field">
                                    <input type="text" name="first_name" placeholder="First Name *" required value="<?php echo e(old('first_name')); ?>">
                                    <div class="icon-holder">
                                        <i class="fa fa-user" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <?php if($errors->has('last_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                                <?php endif; ?>
                                <div class="input-field">
                                    <input type="text" name="last_name" placeholder="Last Name *" required value="<?php echo e(old('last_name')); ?>">
                                    <div class="icon-holder">
                                        <i class="fa fa-user" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div> 

                            <div class="col-md-12">
                                <?php if($errors->has('phone')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                <?php endif; ?>
                                <div class="input-field">
                                    <input type="tel" name="phone" placeholder="Phone Number *" required value="<?php echo e(old('phone')); ?>">
                                    <div class="icon-holder">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <?php if($errors->has('profession')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('profession')); ?></span>
                                <?php endif; ?>
                                <div class="input-field">
                                    <input type="text" name="profession" placeholder="Professional Discipline *" required value="<?php echo e(old('profession')); ?>">
                                    <div class="icon-holder">
                                        <i class="fa fa-user" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                                <div class="input-field">
                                    <input type="email" name="email" placeholder="Enter Email *" required value="<?php echo e(old('email')); ?>">
                                    <div class="icon-holder">
                                        <i class="fa fa-envelope" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <?php if($errors->has('password')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                                <div class="input-field">
                                    <input type="password" name="password" placeholder="Enter Password *" required value="<?php echo e(old('password')); ?>">
                                    <div class="icon-holder">
                                        <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-lg-5 col-md-3 col-sm-4 col-xs-12">
                                        <button class="thm-btn bgclr-1" type="submit">Register</button>
                                    </div>
                                    <div class="col-lg-7 col-md-9 col-sm-8 col-xs-12">
                                        <h6><span>*</span>You must fill all the fields. </h6>
                                    </div>
                                </div>   
                            </div> 
                        </form>    
                    </div>
                </div>    
            </div>
                
            </div>
            <div class="col-lg-4 col-md-5 col-sm-7 col-xs-12 pull-left">
                <div class="left-sidebar">
                    <!--Start single sidebar-->
                    <div class="single-sidebar">
                        <ul class="page-link">
                            <li><a href="/register-undergraduate">UnderGraduate</a></li>
                            <li><a class="active" href="/register-young-professional">Young Professional</a></li>
                            <li><a href="/register-corporate-professional">Corporate Professional</a></li>
                            <li><a href="register-corporate-organization">Corporate Organisation</a></li>             
                        </ul>
                    </div>
                    <!--End single sidebar-->
                
           
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Business planning area-->




<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/laravel/step/resources/views/frontend/account/register.blade.php ENDPATH**/ ?>