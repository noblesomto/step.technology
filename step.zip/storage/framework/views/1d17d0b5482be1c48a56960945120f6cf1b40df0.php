<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(<?php echo e(asset('frontend/img/banner.jpg')); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs">
                    <h1>Our Event</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start breadcrumb bottom area-->     
<section class="breadcrumb-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="left pull-left">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                        <li class="active">Event</li>
                    </ul>
                </div>
                <div class="right pull-right">
                    <a href="#">
                        <span><i class="fa fa-share-alt" aria-hidden="true"></i>Share</span> 
                    </a>   
                </div>    
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb bottom area-->

<!--Start blog area-->
<section id="blog-area" class="blog-default-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="blog-post">
                    <div class="row">
                        <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--Start single blog post-->
                        <div class="col-md-4">
                            <div class="single-blog-item">
                                <div class="img-holder">
                                    <img src="<?php echo e(asset('uploads/thumbnails/'.$row->event_picture)); ?>" alt="<?php echo e($row->event_title); ?>">
                                    <div class="overlay-style-one">
                                        <div class="box">
                                            <div class="content">
                                                <a href="/events/<?php echo e($row->event_id); ?>/<?php echo e($row->event_slug); ?>"><i class="fa fa-link" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="post-date">
                                        <h5><?php echo e($row->created_at->format('j F')); ?></h5>    
                                    </div>
                                </div>
                                <div class="text-holder">
                                    
                                    <a href="/events/<?php echo e($row->event_id); ?>/<?php echo e($row->event_slug); ?>">
                                        <h3 class="blog-title"><?php echo Str::words($row->event_title, 10); ?></h3>
                                    </a>
                                    <div class="text">
                                        <?php echo Str::words($row->event_body, 15); ?>

                                    </div>
                                    <div class="bottom">
                                        <div class="left pull-left">
                                            <a href="/events/<?php echo e($row->event_id); ?>/<?php echo e($row->event_slug); ?>">Read More</a>
                                        </div>
                                        <div class="right pull-right">
                                            
                                        </div>    
                                    </div>
                                </div>    
                            </div>    
                        </div>
                        <!--End single blog post-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
     
                      
                    </div>
                    <!--Start post pagination-->
                    <div class="row">
                        <div class="col-md-12 text-center"> 
                            <?php echo $event->links(); ?>

                        </div> 
                    </div>
                    <!--End post pagination-->
                </div>
            </div>
        </div>
    </div>
</section>
 





<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/laravel/step/resources/views/frontend/events/events.blade.php ENDPATH**/ ?>