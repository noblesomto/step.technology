<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(<?php echo e(asset('frontend/img/banner.jpg')); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs">
                    <h1>ACCOUNT SECTION</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start breadcrumb bottom area-->     
<section class="breadcrumb-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="left pull-left">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                        <li class="active">Login</li>
                    </ul>
                </div>
                <div class="right pull-right">
                    
                </div>    
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb bottom area-->

<!--Start login register area-->
<section class="login-register-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-12 col-sm-12 col-xs-12">
                <div class="form">
                    <div class="sec-title">
                        <h1>Login Now</h1>
                        <span class="border"></span>
                        <p>
                            <?php if(session('status')): ?>
                                <div class="alert alert-<?php echo e(session('status')['type']); ?>">
                                    <?php echo e(session('status')['text']); ?>

                                </div>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="row">
                        <form action="/login" method="POST">
                        <?php echo csrf_field(); ?>
                           
                            <div class="col-md-12">
                                <div class="input-field">
                                    <input type="email" name="email" placeholder="Email Address *" required>
                                    <div class="icon-holder">
                                        <i class="fa fa-envelope" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <div class="input-field">
                                    <input type="password" name="password" placeholder="Enter Password" required>
                                    <div class="icon-holder">
                                        <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                                    </div>
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <button class="thm-btn bgclr-1" type="submit">Login Now</button>
                                        <div class="remember-text">
                                            <div class="checkbox">
                                                <label>
                                                    <input name="remember" type="checkbox">
                                                    <span>Remember Me</span>
                                                </label>
                                            </div>  
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <a class="forgot-password" href="/register">Create Account?</a>
                                            </div>
                                            <div class="col-md-6">
                                                <a class="forgot-password" href="/forgot-password">Forgot Password?</a>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>   
                            </div> 
                        </form>    
                    </div>
                </div>    
            </div>
       
            
        </div>
    </div>
</section>      
<!--End login register area-->




<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/laravel/step/resources/views/frontend/account/login.blade.php ENDPATH**/ ?>