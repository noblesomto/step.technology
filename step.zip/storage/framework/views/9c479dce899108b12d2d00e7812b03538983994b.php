<!DOCTYPE html>
<html>
<head>
    <title>Contact STEP Admin</title>
</head>
<body>
    <p>A user with the following details made an inquiry on the website</p>
    <h1>Name: <?php echo e($details['name']); ?></h1>
    <p>Email: <?php echo e($details['email']); ?></p>
    <p>Phone: <?php echo e($details['phone']); ?></p>
    <p>Subject: <?php echo e($details['subject']); ?></p>
    <p>Message: <?php echo e($details['message']); ?></p>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH /home/www/laravel/step/resources/views/email/contactMail.blade.php ENDPATH**/ ?>